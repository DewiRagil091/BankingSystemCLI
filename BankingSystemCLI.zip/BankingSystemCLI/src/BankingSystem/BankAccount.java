package BankingSystem;

import java.time.LocalDateTime;
import java.util.Random;

public final class BankAccount {
    private final String nama;
    private final String alamat;
    private final String nomor_telepon;
    final String nomor_akun;
    private int saldo;
    private final LocalDateTime tanggal_registrasi;

    public BankAccount(String nama, String alamat, String nomor_telepon, int saldo) {
        this.nama = nama;
        this.alamat = alamat;
        this.nomor_telepon = nomor_telepon;
        this.saldo = saldo;
        this.nomor_akun = generateNomorAkun();
        this.tanggal_registrasi = LocalDateTime.now();
    }

    public void topUp(int jumlahTopUp) {
        saldo += jumlahTopUp;
    }

    public void transfer(int jumlahTransfer) {
        saldo -= jumlahTransfer;
    }

    public String generateNomorAkun() {
        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            sb.append(rand.nextInt(10));
        }
        return sb.toString();
    }

    public void showDescription() {
        System.out.println("Nama: " + nama);
        System.out.println("Alamat: " + alamat);
        System.out.println("Nomor HP: " + nomor_telepon);
        System.out.println("Nomor Akun: " + nomor_akun);
        System.out.println("Saldo: Rp." + saldo);
        System.out.println("Tanggal Registrasi: " + tanggal_registrasi);
    }
}
