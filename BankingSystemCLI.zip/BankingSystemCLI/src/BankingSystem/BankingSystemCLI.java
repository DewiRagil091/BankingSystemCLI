package BankingSystem;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

class BankAccount {
    private String nama;
    private String alamat;
    private String nomor_telepon;
    private String nomor_akun;
    private int saldo;
    private LocalDateTime tanggal_registrasi;

    public BankAccount(String nama, String alamat, String nomor_telepon, int saldo) {
        this.nama = nama;
        this.alamat = alamat;
        this.nomor_telepon = nomor_telepon;
        this.saldo = saldo;
        this.nomor_akun = generateNomorAkun();
        this.tanggal_registrasi = LocalDateTime.now();
    }

    public void topUp(int jumlahTopUp) {
        saldo += jumlahTopUp;
    }

    public void transfer(int jumlahTransfer) {
        saldo -= jumlahTransfer;
    }

    public String generateNomorAkun() {
        Random rand = new Random();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 6; i++) {
            sb.append(rand.nextInt(10));
        }
        return sb.toString();
    }

    public void showDescription() {
        System.out.println("Nama: " + nama);
        System.out.println("Alamat: " + alamat);
        System.out.println("Nomor HP: " + nomor_telepon);
        System.out.println("Nomor Akun: " + nomor_akun);
        System.out.println("Saldo: Rp." + saldo);
        System.out.println("Tanggal Registrasi: " + tanggal_registrasi);
    }

    public String getNomorAkun() {
        return nomor_akun;
    }

    public int getSaldo() {
        return saldo;
    }
}

class BankingSystemCLI {
    private ArrayList<BankAccount> accounts;

    public BankingSystemCLI() {
        accounts = new ArrayList<>();
    }

    public void showMenu() {
        Scanner scanner = new Scanner(System.in);
        int choice = 0;
        do {
            System.out.println("+-----------------------------------------------------+");
            System.out.println("|        WELCOME TO BANKING SYSTEM CLI                |");
            System.out.println("+-----------------------------------------------------+");
            System.out.println("| Silahkan pilih program yang anda mau               |");
            System.out.println("| 1. Registrasi akun baru                            |");
            System.out.println("| 2. Mengirim uang                                   |");
            System.out.println("| 3. Menyimpan uang                                  |");
            System.out.println("| 4. Mengecek informasi rekening pribadi             |");
            System.out.println("| 5. Keluar dari program                             |");
            System.out.println("+-----------------------------------------------------+");
            System.out.print("Pilihan Anda: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline character
            switch (choice) {
                case 1:
                    registrasiAkun();
                    break;
                case 2:
                    mengirimUang();
                    break;
                case 3:
                    menyimpanUang();
                    break;
                case 4:
                    mengecekInformasiRekening();
                    break;
                case 5:
                    System.out.println("Terima kasih telah menggunakan layanan kami.");
                    break;
                default:
                    System.out.println("Pilihan tidak valid, silahkan coba lagi.");
            }
        } while (choice != 5);
    }

    private void registrasiAkun() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("+-----------------------------------------------------+");
        System.out.println("|              REGISTRASI AKUN BARU                   |");
        System.out.println("+-----------------------------------------------------+");
        System.out.print("Masukkan nama anda: ");
        String nama = scanner.nextLine();
        System.out.print("Masukkan alamat anda: ");
        String alamat = scanner.nextLine();
        System.out.print("Masukkan nomor telepon anda: ");
        String nomor_telepon = scanner.nextLine();
        System.out.print("Masukkan saldo awal anda: Rp. ");
        int saldo = scanner.nextInt();
        BankAccount account = new BankAccount(nama, alamat, nomor_telepon, saldo);
        accounts.add(account);
        System.out.println("Akun bank berhasil dibuat! Silahkan nikmati layanan yang kami sediakan.");
        account.showDescription();
    }

    private void mengirimUang() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("+-----------------------------------------------------+");
        System.out.println("|                 MENGIRIM UANG                        |");
        System.out.println("+-----------------------------------------------------+");
        System.out.print("Masukkan nomor akun pengirim: ");
        String nomorPengirim = scanner.nextLine();
        System.out.print("Masukkan nomor akun penerima: ");
        String nomorPenerima = scanner.nextLine();
        System.out.print("Masukkan jumlah uang yang akan ditransfer: Rp. ");
        int jumlahTransfer = scanner.nextInt();

        BankAccount pengirim = getAccountByNomorAkun(nomorPengirim);
        BankAccount penerima = getAccountByNomorAkun(nomorPenerima);

        if (pengirim == null || penerima == null) {
            System.out.println("Nomor akun pengirim atau penerima tidak ditemukan.");
            return;
        }

        if (pengirim.getSaldo() < jumlahTransfer) {
            System.out.println("Saldo tidak mencukupi.");
            return;
        }

        pengirim.transfer(jumlahTransfer);
        penerima.topUp(jumlahTransfer);

        System.out.println("Transaksi berhasil.");
        System.out.println("========================================================");
        System.out.println("Nomor akun pengirim: " + nomorPengirim);
        System.out.println("Nomor akun penerima: " + nomorPenerima);
        System.out.println("Jumlah transfer: Rp." + jumlahTransfer);
        System.out.println("Waktu transaksi: " + LocalDateTime.now());
        System.out.println("========================================================");
    }

    private void menyimpanUang() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("+-----------------------------------------------------+");
        System.out.println("|                 MENYIMPAN UANG                       |");
        System.out.println("+-----------------------------------------------------+");
        System.out.print("Masukkan nomor akun anda: ");
        String nomorAkun = scanner.nextLine();
        System.out.print("Masukkan jumlah uang yang akan disimpan: Rp. ");
        int jumlahUang = scanner.nextInt();

        BankAccount account = getAccountByNomorAkun(nomorAkun);

        if (account == null) {
            System.out.println("Nomor akun tidak ditemukan.");
            return;
        }

        account.topUp(jumlahUang);
        System.out.println("Deposit successful.");
        System.out.println("========================================================");
        account.showDescription();
        System.out.println("Waktu transaksi: " + LocalDateTime.now());
        System.out.println("========================================================");
    }

    private void mengecekInformasiRekening() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("+-----------------------------------------------------+");
        System.out.println("|        MENGCEK INFORMASI REKENING PRIBADI            |");
        System.out.println("+-----------------------------------------------------+");
        System.out.print("Masukkan nomor akun anda: ");
        String nomorAkun = scanner.nextLine();
        BankAccount account = getAccountByNomorAkun(nomorAkun);
        if (account != null) {
            System.out.println("Berikut data registrasi anda:");
            System.out.println("========================================================");
            account.showDescription();
            System.out.println("========================================================");
        } else {
            System.out.println("Nomor akun tidak ditemukan.");
        }
    }

    private BankAccount getAccountByNomorAkun(String nomorAkun) {
        for (BankAccount account : accounts) {
            if (account.getNomorAkun().equals(nomorAkun)) {
                return account;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        try {
            BankingSystemCLI bankingSystemCLI = new BankingSystemCLI();
            bankingSystemCLI.showMenu();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
